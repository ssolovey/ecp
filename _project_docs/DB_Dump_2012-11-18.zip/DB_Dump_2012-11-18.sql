-- phpMyAdmin SQL Dump
-- version 3.4.11.1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Ноя 18 2012 г., 06:55
-- Версия сервера: 5.1.65
-- Версия PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `magento_userss`
--

-- --------------------------------------------------------

--
-- Структура таблицы `reman_warranties`
--

CREATE TABLE IF NOT EXISTS `reman_warranties` (
  `warranty_id` int(2) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Warranty ID',
  `warranty` varchar(35) DEFAULT NULL COMMENT 'Warranty text',
  PRIMARY KEY (`warranty_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Warranty table' AUTO_INCREMENT=24 ;

--
-- Дамп данных таблицы `reman_warranties`
--

INSERT INTO `reman_warranties` (`warranty_id`, `warranty`) VALUES
(13, '6 Month/6,000 Mile Warranty'),
(14, '12 Month/12,000 Mile Warranty'),
(16, '18 Month/18,000 Mile Warranty'),
(19, '24 Month/Unlimited Miles Warranty'),
(23, '36 Month/100,000 Mile Warranty');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
